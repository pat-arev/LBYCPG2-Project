<?php
require "db.php";

$note_id = $_POST['note_id'] ?? null;
if (!$note_id) {
    echo json_encode(["status"=>"error","message"=>"Missing note_id"]);
    exit;
}

// Get current pinned value
$result = $conn->query("SELECT pinned FROM notes WHERE id = $note_id");
$row = $result->fetch_assoc();
$current = (int)$row['pinned'];

// Toggle: 1 → 0, 0 → 1
$newValue = $current ? 0 : 1;

$conn->query("UPDATE notes SET pinned = $newValue WHERE id = $note_id");

echo json_encode([
    "status" => "ok",
    "pinned" => $newValue
]);
?>
