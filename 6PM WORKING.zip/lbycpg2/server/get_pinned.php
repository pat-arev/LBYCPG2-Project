<?php
require "db.php";

$sql = "
    SELECT notes.id, notes.title, notebooks.name AS notebook_name
    FROM notes
    JOIN notebooks ON notes.notebook_id = notebooks.id
    WHERE notes.pinned = 1
    ORDER BY notes.id DESC
";

$result = $conn->query($sql);

$pinned = [];
while ($row = $result->fetch_assoc()) {
    $pinned[] = $row;
}

echo json_encode($pinned);
?>
