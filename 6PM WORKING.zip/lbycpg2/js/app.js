/* ============================================================
    app.js — DB-Backed Notes App (update-capable)
============================================================ */

console.log("app.js loaded");

/* ---------- State ---------- */
let notebooks = [];
let activeNotebookId = null;
let activeNoteId = null; // <-- important: track current note being edited

/* ---------- Helpers ---------- */
function qs(id) { return document.getElementById(id); }
function escapeHtml(s) {
    if (!s) return "";
    return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function safeText(s) { return s == null ? "" : s; }

/* ============================================================
    LOAD NOTEBOOKS (with their notes)
============================================================ */
async function loadNotebooks() {
    try {
        const res = await fetch("server/get_notebooks.php");
        notebooks = await res.json();
        renderNotebooks();
        populateSaveDropdown();
    } catch (err) {
        console.error("loadNotebooks error:", err);
    }
}

/* ============================================================
    RENDER NOTEBOOK SIDEBAR
============================================================ */
function renderNotebooks() {
    const section = qs("notebookSection");
    section.innerHTML = "";

    notebooks.forEach(nb => {
        let html = `
            <div class="notebook-group mb-1">

                <!-- TOGGLE -->
                <div class="notebook-toggle" data-nb="${nb.id}" style="font-weight:600; cursor:pointer;">
                    ▼ ${escapeHtml(nb.name)}
                </div>

                <!-- NOTES INSIDE NOTEBOOK -->
                <div class="notebook-items" id="nb-items-${nb.id}" style="display:none;">
        `;

        if (!nb.notes || nb.notes.length === 0) {
            html += `<div class="note-item text-muted">(No notes)</div>`;
        } else {
            nb.notes.forEach(n => {
                html += `
                    <div class="notebook-note note-item d-flex justify-content-between align-items-center"
                         data-note-id="${n.id}"
                         style="padding:8px; border-radius:6px; margin-bottom:6px; cursor:pointer;">

                        <strong>${escapeHtml(n.title || "(Untitled)")}</strong>

                        <button class="pin-btn" data-id="${n.id}" title="Pin note">📌</button>
                    </div>
                `;
            });
        }

        html += `
                </div>
            </div>
        `;

        section.insertAdjacentHTML("beforeend", html);
    });

    // Attach events AFTER rendering
    attachNotebookToggleEvents();
    attachNoteClickEvents();
    attachPinEvents();
}


function loadPinned() {
    fetch("server/get_pinned.php")
        .then(r => r.json())
        .then(list => {
            const box = qs("pinnedNotes");
            box.innerHTML = "";

            if (!list.length) {
                box.innerHTML = `<div class="text-muted">No pinned notes</div>`;
                return;
            }

            list.forEach(n => {
                let el = document.createElement("div");
                el.className = "note-item";
                el.innerHTML = `
                    <strong>${escapeHtml(n.title)}</strong><br>
                    <small>${escapeHtml(n.notebook_name)}</small>
                `;
                el.addEventListener("click", () => loadNoteIntoEditor(n.id));
                box.appendChild(el);
            });
        });
}

document.querySelectorAll(".pin-btn").forEach(btn => {
    btn.addEventListener("click", e => {
        e.stopPropagation(); // prevent opening note

        const id = btn.dataset.id;
        let fd = new FormData();
        fd.append("note_id", id);

        fetch("server/pin_note.php", {
            method: "POST",
            body: fd
        })
            .then(r => r.text())
            .then(res => {
                console.log("PIN RESPONSE:", res);
                if (res.trim() === "OK") {
                    loadPinned();
                }
            })
            .catch(err => console.error("Pin error:", err));
    });
});


/* ============================================================
    TOGGLE EVENTS
============================================================ */
function attachNotebookToggleEvents() {
    document.querySelectorAll(".notebook-toggle").forEach(toggle => {
        toggle.onclick = () => {
            const nbId = toggle.dataset.nb;
            const items = qs("nb-items-" + nbId);

            if (!items) return;

            const isHidden = items.style.display === "none";
            items.style.display = isHidden ? "block" : "none";

            toggle.innerHTML = (isHidden ? "▼ " : "► ") + toggle.innerText.slice(2);
        };
    });
}

function attachPinEvents() {
    document.querySelectorAll(".pin-btn").forEach(btn => {
        btn.addEventListener("click", e => {
            e.stopPropagation(); // prevent opening note when pinning

            const noteId = btn.dataset.id;
            let fd = new FormData();
            fd.append("note_id", noteId);

            fetch("server/pin_note.php", {
                method: "POST",
                body: fd
            })
                .then(r => r.text())
                .then(res => {
                    if (res.trim() === "OK") {
                        loadPinned();
                    } else {
                        console.error("Pin failed:", res);
                    }
                })
                .catch(err => console.error("Pin ERROR:", err));
        });
    });
}



/* ============================================================
    NOTE CLICK EVENTS -> load note into editor
============================================================ */
function attachNoteClickEvents() {
    document.querySelectorAll(".note-item").forEach(item => {
        item.onclick = () => {
            const id = item.dataset.noteId;
            if (id) loadNoteIntoEditor(id);
        };
    });
}

function attachPinEvents() {
    document.querySelectorAll(".pin-btn").forEach(btn => {
        btn.addEventListener("click", e => {
            e.stopPropagation(); // prevent opening the note
            const noteId = btn.dataset.id;
            togglePin(noteId);
        });
    });
}


/* ============================================================
    POPULATE SAVE DROPDOWN
============================================================ */
function populateSaveDropdown() {
    const dd = qs("notebookDropdown");
    if (!dd) return;
    dd.innerHTML = "";
    notebooks.forEach(nb => {
        const opt = document.createElement("option");
        opt.value = nb.id;
        opt.textContent = nb.name;
        dd.appendChild(opt);
    });

    // if activeNotebookId set, select it
    if (activeNotebookId && dd.querySelector(`option[value="${activeNotebookId}"]`)) {
        dd.value = activeNotebookId;
    }
}

/* ============================================================
    LOAD ALL NOTES (global list)
============================================================ */
function loadAllNotes() {
    fetch("server/get_notes.php")
        .then(r => r.json())
        .then(notes => {
            const list = qs("noteList");
            if (!list) return;
            list.innerHTML = "";
            if (!notes || notes.length === 0) {
                list.innerHTML = `<div class="note-item text-muted">No notes yet</div>`;
                return;
            }
            notes.forEach(n => {
                const el = document.createElement("div");
                el.className = "note-item";
                el.dataset.noteId = n.id;
                el.innerHTML = `<strong>${escapeHtml(n.title || "(Untitled)")}</strong>`;
                el.addEventListener("click", () => loadNoteIntoEditor(n.id));
                list.appendChild(el);
            });
        })
        .catch(err => console.error("loadAllNotes error:", err));
}

/* ============================================================
    LOAD SINGLE NOTE INTO EDITOR
============================================================ */
function loadNoteIntoEditor(noteId) {
    fetch("server/get_note.php?id=" + encodeURIComponent(noteId))
        .then(r => r.json())
        .then(note => {
            if (!note) return;
            activeNoteId = note.id;
            activeNotebookId = note.notebook_id || activeNotebookId;

            qs("noteTitle").value = safeText(note.title);
            qs("editor").innerHTML = safeText(note.content);

            // preselect notebook in save modal dropdown
            const dd = qs("notebookDropdown");
            if (dd && note.notebook_id) dd.value = note.notebook_id;

            // Optionally focus editor
            try { qs("editor").focus(); } catch (e) { }
        })
        .catch(err => console.error("loadNoteIntoEditor error:", err));
}

/* ============================================================
    SAVE (create or update)
    Sends notebook_id, title, content, optional note_id
============================================================ */
async function saveNoteToServer(formData) {
    const res = await fetch("server/save_note.php", { method: "POST", body: formData });
    const text = await res.text();
    // try parse JSON (our server returns JSON)
    try {
        return JSON.parse(text);
    } catch (e) {
        return { status: "error", message: text };
    }
}

/* ============================================================
    ADD NOTEBOOK AJAX
============================================================ */
function addNotebookAjax(name) {
    const fd = new FormData();
    fd.append("name", name);
    return fetch("server/add_notebook.php", { method: "POST", body: fd })
        .then(r => r.text());
}

/* ============================================================
   QUICK SAVE — saves immediately without modal
============================================================ */
async function quickSaveNote() {
    let title = qs("noteTitle").value.trim();
    const content = qs("editor").innerHTML;

    // Determine notebook
    let notebookId = activeNotebookId;
    if (!notebookId) {
        // fallback: use the first notebook
        if (notebooks.length > 0) {
            notebookId = notebooks[0].id;
        } else {
            alert("No notebooks exist yet.");
            return;
        }
    }

    // Auto-title untitled notes
    if (!title) {
        const now = new Date();
        const time = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
        title = `Untitled - ${time}`;
    }

    const fd = new FormData();
    fd.append("notebook_id", notebookId);
    fd.append("title", title);
    fd.append("content", content);

    // If editing existing note → update instead of create
    if (activeNoteId && Number(activeNoteId) > 0) {
        fd.append("note_id", activeNoteId);
    }

    const result = await saveNoteToServer(fd);

    if (result.status === "ok") {
        // Update activeNoteId if newly created
        if (result.action === "created") {
            activeNoteId = result.id;
        }

        // refresh UI
        await loadNotebooks();
        await loadAllNotes();

        // success message
        alert("Note saved successfully!");
    } else {
        alert("Save failed: " + (result.message || "Unknown error"));
    }
}

function togglePin(noteId) {
    const fd = new FormData();
    fd.append("note_id", noteId);

    fetch("server/toggle_pin.php", {
        method: "POST",
        body: fd
    })
        .then(r => r.json())
        .then(res => {
            if (res.status === "ok") {
                loadPinned();
                loadAllNotes();
                loadNotebooks();
            } else {
                console.error(res);
            }
        });
}


/* ============================================================
    DOM Ready - wire events
============================================================ */
document.addEventListener("DOMContentLoaded", () => {

    // initial loads
    loadNotebooks();
    loadAllNotes();

    // QUICK SAVE button (no modal)
    const quickBtn = qs("quickSaveBtn");
    if (quickBtn) {
        quickBtn.addEventListener("click", quickSaveNote);
    }

    // New Note button: clear and open modal
    const newNoteBtn = qs("newNoteBtn");
    if (newNoteBtn) {
        newNoteBtn.addEventListener("click", () => {
            activeNoteId = 0; // creating a new note
            qs("noteTitle").value = "";
            qs("editor").innerHTML = "";
            // show save modal
            const modal = new bootstrap.Modal(qs("saveNoteModal"));
            modal.show();
        });
    }

    // Save note form handler
    const saveForm = qs("saveNoteForm");
    if (saveForm) {
        saveForm.addEventListener("submit", async (e) => {
            e.preventDefault();

            const dd = saveForm.querySelector("[name='notebook_id']");
            const notebookId = dd ? dd.value : null;
            let title = qs("noteTitle").value.trim();
            const content = qs("editor").innerHTML;

            if (!notebookId) {
                alert("Please select a notebook.");
                return;
            }

            // If no title, auto-generate like you requested
            if (!title) {
                const now = new Date();
                const time = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
                title = `Untitled - ${time}`;
            }

            // Build form data
            const fd = new FormData();
            fd.append("notebook_id", notebookId);
            fd.append("title", title);
            fd.append("content", content);

            // If editing existing note, include note_id
            if (activeNoteId && Number(activeNoteId) > 0) {
                fd.append("note_id", activeNoteId);
            }

            // disable submit UI
            const submitBtn = saveForm.querySelector("button[type='submit']");
            const origText = submitBtn ? submitBtn.textContent : "Save";
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.textContent = "Saving...";
            }

            const result = await saveNoteToServer(fd);

            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.textContent = origText;
            }

            if (result.status && result.status === "ok") {
                const modalEl = qs("saveNoteModal");
                const modal = bootstrap.Modal.getInstance(modalEl) || new bootstrap.Modal(modalEl);
                modal.hide();

                // if created, set activeNoteId to new id so future saves update
                if (result.action === "created" && result.id) {
                    activeNoteId = result.id;
                }

                // refresh UI: reload notebooks+notes or selectively update
                await loadNotebooks();
                await loadAllNotes();

                // ensure the notebook's items visible and notebook selected
                activeNotebookId = notebookId;
                populateSaveDropdown();

            } else {
                const msg = result.message || "Save failed";
                alert(msg);
                console.error("Save error:", result);
            }
        });
    }

    // Create notebook
    const createBtn = qs("confirmAddNotebook");
    if (createBtn) {
        createBtn.addEventListener("click", () => {
            const name = qs("newNotebookName").value.trim();
            if (!name) return alert("Notebook name required.");
            createBtn.disabled = true;
            createBtn.textContent = "Creating...";
            addNotebookAjax(name).then(newId => {
                createBtn.disabled = false;
                createBtn.textContent = "Create";
                if (!isNaN(newId)) {
                    // reload notebooks
                    qs("newNotebookName").value = "";
                    const modal = bootstrap.Modal.getInstance(qs("addNotebookModal"));
                    modal.hide();
                    loadNotebooks();
                } else {
                    alert("Failed to create notebook: " + newId);
                }
            }).catch(err => {
                createBtn.disabled = false;
                createBtn.textContent = "Create";
                console.error(err);
                alert("Failed to create notebook");
            });
        });
    }

    // When Save modal opens, try to preselect current notebook
    const saveModalEl = qs("saveNoteModal");
    if (saveModalEl) {
        saveModalEl.addEventListener("show.bs.modal", () => {
            const dd = qs("notebookDropdown");
            if (!dd) return;
            if (activeNotebookId && dd.querySelector(`option[value="${activeNotebookId}"]`)) {
                dd.value = activeNotebookId;
            } else if (dd.options.length) {
                dd.value = dd.options[0].value;
            }
        });
    }
});
