<?php
require "db.php";

$noteId = $_POST['id'] ?? 0;

$sql = "UPDATE notes SET pinned = 0 WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $noteId);

if ($stmt->execute()) echo "OK";
else echo "ERR";
