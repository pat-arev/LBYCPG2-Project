<?php
require "db.php";

if (!isset($_POST['name']) || trim($_POST['name']) === '') {
    http_response_code(400);
    echo "missing";
    exit;
}

$name = $_POST['name'];

$stmt = $conn->prepare("INSERT INTO notebooks (name) VALUES (?)");
$stmt->bind_param("s", $name);

if ($stmt->execute()) {
    echo $stmt->insert_id;
} else {
    http_response_code(500);
    echo "error";
}
$stmt->close();
