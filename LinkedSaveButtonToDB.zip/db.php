<?php
$host = "localhost";
$user = "root";      // default XAMPP user
$pass = "";          // default is empty password
$dbname = "notes_app";   // the database name you made

$conn = mysqli_connect($host, $user, $pass, $dbname);

if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}
?>