<?php
require "db.php";

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

header("Content-Type: application/json");

$notebooks = [];

// Load all notebooks
$nbQuery = $conn->query("SELECT id, name FROM notebooks ORDER BY id ASC");

while ($nb = $nbQuery->fetch_assoc()) {

    $notebookId = (int)$nb['id'];

    // Load notes for this notebook
    $sql = "
        SELECT id, title
        FROM notes 
        WHERE notebook_id = $notebookId
        ORDER BY id DESC
    ";

    $notesQuery = $conn->query($sql);

    $notes = [];
    while ($n = $notesQuery->fetch_assoc()) {
        if (!$n['title']) $n['title'] = "(Untitled)";
        $notes[] = $n;
    }

    $nb['notes'] = $notes;
    $notebooks[] = $nb;
}

echo json_encode($notebooks);
