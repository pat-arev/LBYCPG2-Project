console.log("app.js LOADED");

setupDarkMode();
renderNotes();
setupSearch();
setupTagInput();

