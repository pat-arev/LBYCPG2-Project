<?php
require "db.php";

$result = $conn->query("SELECT id, name FROM notebooks ORDER BY name ASC");

$rows = [];

while ($row = $result->fetch_assoc()) {
    $rows[] = $row;
}

echo json_encode($rows);
