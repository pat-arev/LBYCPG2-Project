<?php
require __DIR__ . "/db.php";   // loads $conn

if (!isset($_POST["note_id"])) {
    echo "Missing ID";
    exit;
}

$id = intval($_POST["note_id"]);

// Prepare delete query
$stmt = $conn->prepare("DELETE FROM notes WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    echo "OK";
} else {
    echo "DB_ERROR";
}

$stmt->close();
$conn->close();
