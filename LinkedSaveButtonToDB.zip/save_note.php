<?php
// db.php - Database connection
$host = "localhost";
$user = "root";
$pass = ""; // default XAMPP password is empty
$dbname = "notes_app"; // your database name

$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form was submitted
if (isset($_POST['notebook'], $_POST['title'], $_POST['content'])) {

    $notebook = $_POST['notebook']; // table name
    $title = $_POST['title'];
    $content = $_POST['content'];

    // Optional: basic validation
    if (empty($title) && empty($content)) {
        die("Note cannot be empty");
    }

    // Prepare SQL statement
    $stmt = $conn->prepare("INSERT INTO `$notebook` (title, content) VALUES (?, ?)");
    $stmt->bind_param("ss", $title, $content);

    if ($stmt->execute()) {
        echo "Note saved successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();

} else {
    echo "No data received.";
}

$conn->close();
?>
