console.log("Add Notebook Loaded.");

function addNotebook() {
    const name = document.getElementById("newNotebookName").value.trim();

    if (!name) {
        alert("Notebook name cannot be empty.");
        return;
    }

    let form = new FormData();
    form.append("name", name);

    fetch("server/add_notebook.php", {
        method: "POST",
        body: form
    })
        .then(res => res.text())
        .then(id => {
            if (id === "error") {
                alert("Failed to create notebook.");
                return;
            }

            notebooks.push({
                id: id,
                name: name,
                expanded: true
            });

            document.getElementById("newNotebookName").value = "";

            const modal = bootstrap.Modal.getInstance(document.getElementById("addNotebookModal"));
            modal.hide();

            renderNotebooks();
        });
}
