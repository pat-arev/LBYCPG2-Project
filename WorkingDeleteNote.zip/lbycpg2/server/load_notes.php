<?php
require "db.php";

$notebook_id = $_GET["notebook"] ?? null;

if (!$notebook_id) {
    echo json_encode([]);
    exit;
}

$stmt = $conn->prepare("SELECT id, title, content, created_at 
                        FROM notes 
                        WHERE notebook_id = ?
                        ORDER BY id DESC");
$stmt->bind_param("i", $notebook_id);
$stmt->execute();

$result = $stmt->get_result();
$notes = [];

while ($row = $result->fetch_assoc()) {
    $notes[] = $row;
}

echo json_encode($notes);
