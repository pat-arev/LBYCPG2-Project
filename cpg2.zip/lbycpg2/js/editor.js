console.log("Enhanced Editor Toolbar Loaded");

// Detect toolbar buttons
const toolbarButtons = document.querySelectorAll('.editor-toolbar button');
const editor = document.getElementById("editor");

/* -----------------------------
   MAIN BUTTON CLICK HANDLER
----------------------------- */
toolbarButtons.forEach(btn => {
    btn.addEventListener("click", () => {
        const cmd = btn.dataset.cmd;

        switch (cmd) {
            case "bold":
            case "italic":
                document.execCommand(cmd);
                break;

            case "h1":
                toggleHeading("h1", btn);
                break;

            case "h2":
                toggleHeading("h2", btn);
                break;

            case "ul":
                toggleList(btn);
                break;

            case "quote":
                toggleQuote(btn);
                break;

            case "code":
                toggleCodeBlock(btn);
                break;
        }

        updateActiveStates();
    });
});

/* -----------------------------
   TOGGLE LIST
----------------------------- */
function toggleList(button) {
    document.execCommand("insertUnorderedList");
}

/* -----------------------------
   TOGGLE HEADING (H1 / H2)
----------------------------- */
function toggleHeading(tag, button) {
    const selection = window.getSelection();
    if (!selection.rangeCount) return;

    let parent = selection.anchorNode.parentNode;

    if (parent.tagName && parent.tagName.toLowerCase() === tag) {
        // Remove heading → back to paragraph
        document.execCommand("formatBlock", false, "p");
    } else {
        // Apply heading
        document.execCommand("formatBlock", false, tag);
    }
}

/* -----------------------------
   TOGGLE QUOTE
----------------------------- */
function toggleQuote(button) {
    const selection = window.getSelection();
    let parent = selection.anchorNode.parentNode;

    if (parent.tagName && parent.tagName.toLowerCase() === "blockquote") {
        document.execCommand("formatBlock", false, "p");
    } else {
        document.execCommand("formatBlock", false, "blockquote");
    }
}

/* -----------------------------
   TOGGLE CODE BLOCK
----------------------------- */
function toggleCodeBlock(button) {
    const sel = window.getSelection();
    let parent = sel.anchorNode.parentNode;

    if (parent.tagName && parent.tagName.toLowerCase() === "pre") {
        // Remove code block
        document.execCommand("formatBlock", false, "p");
    } else {
        // Apply code block
        document.execCommand("formatBlock", false, "pre");
    }
}

/* -----------------------------
   UPDATE ACTIVE BUTTON STATES
----------------------------- */
function updateActiveStates() {
    toolbarButtons.forEach(btn => btn.classList.remove("active"));

    const sel = window.getSelection();
    if (!sel.rangeCount) return;

    let node = sel.anchorNode;
    if (node.nodeType === 3) node = node.parentNode;

    const tag = node.tagName?.toLowerCase();

    toolbarButtons.forEach(btn => {
        const cmd = btn.dataset.cmd;

        if (cmd === "bold" && document.queryCommandState("bold")) {
            btn.classList.add("active");
        }

        if (cmd === "italic" && document.queryCommandState("italic")) {
            btn.classList.add("active");
        }

        if (cmd === "ul" && document.queryCommandState("insertUnorderedList")) {
            btn.classList.add("active");
        }

        if (cmd === "quote" && tag === "blockquote") {
            btn.classList.add("active");
        }

        if (cmd === "code" && tag === "pre") {
            btn.classList.add("active");
        }

        if (cmd === "h1" && tag === "h1") {
            btn.classList.add("active");
        }

        if (cmd === "h2" && tag === "h2") {
            btn.classList.add("active");
        }
    });
}

/* -----------------------------
   UPDATE ACTIVE STATE ON CURSOR CHANGE
----------------------------- */
document.addEventListener("selectionchange", () => {
    if (document.activeElement === editor) {
        updateActiveStates();
    }
});
