<?php
require "db.php";

$noteId = $_POST["note_id"] ?? 0;
if (!$noteId) {
    echo "Invalid ID";
    exit;
}

$sql = "UPDATE notes SET pinned = 1 WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $noteId);

if ($stmt->execute()) {
    echo "OK";
} else {
    echo "DB_ERROR";
}

$stmt->close();
$conn->close();
?>
