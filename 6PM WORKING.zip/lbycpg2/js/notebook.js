function loadNotebooks() {
    fetch("server/get_notebooks.php")
        .then(res => res.json())
        .then(data => {
            const section = document.querySelector(".notebook-section");
            section.innerHTML = "";

            data.forEach(nb => {
                const group = document.createElement("div");
                group.className = "notebook-group";

                group.innerHTML = `
                    <div class="notebook-toggle">▼ ${nb.name}</div>
                    <div class="notebook-items">
                        ${nb.notes.map(n => `
                            <div class="note-item" data-id="${n.id}">
                                ${n.title || "(Untitled)"}
                            </div>
                        `).join("")}
                    </div>
                `;

                section.appendChild(group);
            });

            // click note → load into editor  
            document.querySelectorAll(".note-item").forEach(item => {
                item.addEventListener("click", () => {
                    loadNoteIntoEditor(item.dataset.id);
                });
            });

            // collapsible sidebar
            document.querySelectorAll(".notebook-toggle").forEach(t => {
                t.addEventListener("click", () => {
                    const items = t.nextElementSibling;
                    items.style.display = items.style.display === "none" ? "block" : "none";
                });
            });
        });
}

// load on startup
loadNotebooks();
