<?php
require "db.php";
header("Content-Type: application/json; charset=utf-8");

// Expect: notebook_id, title, content
// Optional: note_id (when present -> do UPDATE)

$notebook_id = isset($_POST['notebook_id']) ? intval($_POST['notebook_id']) : null;
$title = isset($_POST['title']) ? $_POST['title'] : "";
$content = isset($_POST['content']) ? $_POST['content'] : "";
$note_id = isset($_POST['note_id']) ? intval($_POST['note_id']) : 0;

if (!$notebook_id) {
    echo json_encode(["status" => "error", "message" => "Missing notebook_id"]);
    exit;
}

// allow empty notes as you requested

if ($note_id && $note_id > 0) {
    // UPDATE existing note
    $stmt = $conn->prepare("UPDATE notes SET notebook_id = ?, title = ?, content = ? WHERE id = ?");
    if (!$stmt) {
        echo json_encode(["status" => "error", "message" => $conn->error]);
        exit;
    }
    $stmt->bind_param("issi", $notebook_id, $title, $content, $note_id);
    if ($stmt->execute()) {
        echo json_encode(["status" => "ok", "action" => "updated", "id" => $note_id]);
    } else {
        echo json_encode(["status" => "error", "message" => $stmt->error]);
    }
    $stmt->close();
} else {
    // INSERT new note
    $stmt = $conn->prepare("INSERT INTO notes (notebook_id, title, content) VALUES (?, ?, ?)");
    if (!$stmt) {
        echo json_encode(["status" => "error", "message" => $conn->error]);
        exit;
    }
    $stmt->bind_param("iss", $notebook_id, $title, $content);
    if ($stmt->execute()) {
        $newId = $stmt->insert_id;
        echo json_encode(["status" => "ok", "action" => "created", "id" => $newId]);
    } else {
        echo json_encode(["status" => "error", "message" => $stmt->error]);
    }
    $stmt->close();
}

$conn->close();
?>
