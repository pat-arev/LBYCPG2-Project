let demoNotes = [
    { title: "Welcome Note", date: "Jan 10" },
    { title: "Tasks", date: "Jan 9" },
    { title: "Plans", date: "Jan 5" }
];

const noteList = document.getElementById("noteList");

function renderNotes(filter = "") {
    noteList.innerHTML = "";
    demoNotes
        .filter(n => n.title.toLowerCase().includes(filter.toLowerCase()))
        .forEach(n => {
            noteList.innerHTML += `
                <div class="note-item">
                    <strong>${n.title}</strong><br>
                    <small>${n.date}</small>
                </div>
            `;
        });
}

function setupSearch() {
    document.getElementById("searchInput").addEventListener("input", e => {
        renderNotes(e.target.value);
    });
}

document.querySelectorAll('.notebook-toggle').forEach(toggle => {
    toggle.addEventListener("click", () => {
        const group = toggle.nextElementSibling;
        group.style.display = (group.style.display === "none") ? "block" : "none";

        // Flip arrow
        toggle.textContent = toggle.textContent.includes("▼")
            ? toggle.textContent.replace("▼", "►")
            : toggle.textContent.replace("►", "▼");
    });
});

const searchBox = document.getElementById("searchInput");
const suggestionBox = document.getElementById("searchSuggestions");

searchBox.addEventListener("input", () => {
    const q = searchBox.value.toLowerCase();
    if (!q) {
        suggestionBox.style.display = "none";
        return;
    }

    const matches = demoNotes.filter(n => n.title.toLowerCase().includes(q));

    suggestionBox.innerHTML = matches
        .map(m => `<div>${m.title}</div>`)
        .join("");

    suggestionBox.style.display = "block";
});

suggestionBox.addEventListener("click", e => {
    if (e.target.tagName === "DIV") {
        searchBox.value = e.target.textContent;
        suggestionBox.style.display = "none";
        renderNotes(e.target.textContent);
    }
});

let pinnedNotes = [
    { title: "Project Overview", date: "Jan 12" },
    { title: "Important Ideas", date: "Jan 3" }
];

function renderPinned() {
    const box = document.getElementById("pinnedNotes");
    box.innerHTML = pinnedNotes.map(n => `
        <div class="note-item">
            <strong>${n.title}</strong><br>
            <small>${n.date}</small>
        </div>
    `).join("");
}

renderPinned();
