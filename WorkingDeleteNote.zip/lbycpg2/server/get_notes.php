<?php
include "db.php";

$query = "SELECT id, title FROM notes ORDER BY id DESC";
$result = mysqli_query($conn, $query);

$notes = [];

while ($row = mysqli_fetch_assoc($result)) {
    $notes[] = $row;
}

echo json_encode($notes);
?>
