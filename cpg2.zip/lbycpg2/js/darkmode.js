console.log("darkmode.js LOADED");

function setupDarkMode() {
    console.log("setupDarkMode() CALLED");

    const toggle = document.getElementById("toggleDark");

    if (!toggle) {
        console.log("ERROR: toggleDark button not found");
        return;
    }

    toggle.addEventListener("click", () => {
        document.body.classList.toggle("dark-mode");

        if (document.body.classList.contains("dark-mode")) {
            toggle.textContent = "☀️";
        } else {
            toggle.textContent = "🌙";
        }
    });
}
