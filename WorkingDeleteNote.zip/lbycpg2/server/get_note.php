<?php
include "db.php";

$id = $_GET['id'] ?? 0;

$query = "SELECT * FROM notes WHERE id = $id";
$result = mysqli_query($conn, $query);

echo json_encode(mysqli_fetch_assoc($result));
?>
