// INITIAL NOTEBOOK DATA
let notebooks = [
    {
        name: "Personal",
        notes: ["Daily Notes", "Journal"],
        expanded: true
    },
    {
        name: "School",
        notes: ["Assignments", "Projects"],
        expanded: true
    }
];

// RENDER NOTEBOOKS INTO SIDEBAR
function renderNotebooks() {
    const section = document.querySelector(".notebook-section");

    // KEEP your existing HTML header — DO NOT re-render it here
    section.innerHTML = "";

    notebooks.forEach((nb, index) => {
        section.innerHTML += `
            <div class="notebook-group">
                <div class="notebook-toggle" data-id="${index}">
                    ${nb.expanded ? "▼" : "►"} ${nb.name}
                </div>

                <div class="notebook-items" style="display:${nb.expanded ? "block" : "none"}">
                    ${nb.notes.map(n => `<div class="note-item">${n}</div>`).join("")}
                </div>
            </div>
        `;
    });

    attachToggleEvents();
}

// COLLAPSIBLE NOTEBOOKS
function attachToggleEvents() {
    document.querySelectorAll(".notebook-toggle").forEach(toggle => {
        toggle.addEventListener("click", () => {
            const id = toggle.dataset.id;
            notebooks[id].expanded = !notebooks[id].expanded;
            renderNotebooks();
        });
    });
}

// ADD NEW NOTEBOOK
function addNotebook() {
    const name = document.getElementById("newNotebookName").value.trim();
    if (!name) return;

    notebooks.push({
        name: name,
        notes: [],
        expanded: true
    });

    // Clear input
    document.getElementById("newNotebookName").value = "";

    // Close modal
    const modal = bootstrap.Modal.getInstance(document.getElementById("addNotebookModal"));
    modal.hide();

    renderNotebooks();
}

// FIRST LOAD
renderNotebooks();
